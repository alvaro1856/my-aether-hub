(globalThis.TURBOPACK_CHUNK_LISTS || (globalThis.TURBOPACK_CHUNK_LISTS = [])).push({
    script: typeof document === "object" ? document.currentScript : undefined,
    chunks: [
  "static/chunks/[turbopack]_browser_dev_hmr-client_hmr-client_ts_0b8a0026._.js",
  "static/chunks/19721_next_dist_compiled_react-dom_fc2812c3._.js",
  "static/chunks/19721_next_dist_compiled_next-devtools_index_0f9b79f2.js",
  "static/chunks/19721_next_dist_compiled_ef420155._.js",
  "static/chunks/19721_next_dist_client_08bca4c0._.js",
  "static/chunks/19721_next_dist_50200cf7._.js",
  "static/chunks/19721_@swc_helpers_cjs_0ea83710._.js"
],
    source: "entry"
});
