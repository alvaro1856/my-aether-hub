(globalThis.TURBOPACK_CHUNK_LISTS || (globalThis.TURBOPACK_CHUNK_LISTS = [])).push({
    script: typeof document === "object" ? document.currentScript : undefined,
    chunks: [
  "static/chunks/[root-of-the-server]__f0053158._.css",
  "static/chunks/19721_next_dist_715547eb._.js"
],
    source: "dynamic"
});
