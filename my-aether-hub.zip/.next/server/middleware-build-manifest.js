globalThis.__BUILD_MANIFEST = {
  "pages": {
    "/_app": []
  },
  "devFiles": [],
  "ampDevFiles": [],
  "polyfillFiles": [
    "static/chunks/19721_next_dist_build_polyfills_polyfill-nomodule.js"
  ],
  "lowPriorityFiles": [],
  "rootMainFiles": [
    "static/chunks/[turbopack]_browser_dev_hmr-client_hmr-client_ts_0b8a0026._.js",
    "static/chunks/19721_next_dist_compiled_react-dom_fc2812c3._.js",
    "static/chunks/19721_next_dist_compiled_next-devtools_index_0f9b79f2.js",
    "static/chunks/19721_next_dist_compiled_ef420155._.js",
    "static/chunks/19721_next_dist_client_08bca4c0._.js",
    "static/chunks/19721_next_dist_50200cf7._.js",
    "static/chunks/19721_@swc_helpers_cjs_0ea83710._.js",
    "static/chunks/my-aether-hub_a0ff3932._.js",
    "static/chunks/turbopack-my-aether-hub_9ba05d1f._.js"
  ],
  "ampFirstPages": []
};
globalThis.__BUILD_MANIFEST.lowPriorityFiles = [
"/static/" + process.env.__NEXT_BUILD_ID + "/_buildManifest.js",
,"/static/" + process.env.__NEXT_BUILD_ID + "/_ssgManifest.js",

];