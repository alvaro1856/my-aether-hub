import Link from "next/link";

function Check({ children }: { children: React.ReactNode }) {
  return <li className="flex gap-2 items-start"><span>✅</span><span>{children}</span></li>;
}

export default function Home() {
  return (
    <section className="space-y-14">
      <div className="rounded-3xl bg-panel p-10 shadow">
        <h1 className="text-4xl md:text-5xl font-black tracking-tight">
          Ship your software without the chaos.
        </h1>
        <p className="mt-4 text-ink-soft max-w-2xl">
          Aetherhub is your command center—downloads, docs, changelogs, and updates in one place.
        </p>
        <div className="mt-8 flex gap-4">
          <Link href="/download" className="btn btn-brand">Download</Link>
          <Link href="/features" className="btn btn-ghost">See Features</Link>
        </div>
      </div>

      <div className="w-12 h-12 bg-red-500" />


      <div className="grid md:grid-cols-3 gap-6">
        <ValueCard title="Fast setup">Launch a product page in minutes.</ValueCard>
        <ValueCard title="Docs built-in">Guide users without 3rd-party sprawl.</ValueCard>
        <ValueCard title="Changelog">Make updates visible and exciting.</ValueCard>
      </div>

      <div className="rounded-3xl bg-panel p-8">
        <h2 className="text-2xl font-bold mb-4">What you’ll get</h2>
        <ul className="space-y-2">
          <Check>Download channel with latest stable + previous versions</Check>
          <Check>Docs with search</Check>
          <Check>Pricing that’s ready for payments later</Check>
          <Check>Blog + Announcements</Check>
        </ul>
      </div>
    </section>
  );
}

function ValueCard({ title, children }: { title:string; children:React.ReactNode }) {
  return (
    <div className="rounded-2xl p-6 bg-panel border border-ink-border">
      <h3 className="font-semibold text-lg mb-2">{title}</h3>
      <p className="text-ink-soft">{children}</p>
    </div>
  );
}
